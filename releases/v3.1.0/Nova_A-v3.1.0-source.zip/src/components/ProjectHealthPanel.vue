<template>
  <section class="project-health">
    <header><div><strong>{{ t('projectHealth') }}</strong><small>{{ t('projectHealthHint') }}</small></div><span :class="healthClass">{{ summary }}</span></header>
    <div class="health-grid">
      <article><span>{{ t('formatVersion') }}</span><strong>{{ compatibility.format }}</strong><small>schema {{ compatibility.schemaVersion }}</small></article>
      <article><span>{{ t('engineVersion') }}</span><strong>3.1.0</strong><small>{{ t('supportedSchemas', { first: compatibility.minimumSchemaVersion, last: compatibility.schemaVersion }) }}</small></article>
      <article><span>{{ t('scenes') }}</span><strong>{{ sceneManager.scenes.length }}</strong><small>{{ sceneManager.scenes.filter(scene => scene.loaded).length }} {{ t('loaded') }}</small></article>
      <article><span>{{ t('assets') }}</span><strong>{{ assets.records.length }}</strong><small>{{ graph.missingReferences.length }} {{ t('missingReferences') }}</small></article>
      <article><span>{{ t('packages') }}</span><strong>{{ packages.installed.filter(item => item.project).length }}</strong><small>{{ packageProblems.length }} {{ t('problems') }}</small></article>
      <article><span>{{ t('buildPanel') }}</span><strong>{{ buildIssues.length ? t('attentionRequired') : t('ready') }}</strong><small>{{ buildIssues.length }} {{ t('problems') }}</small></article>
    </div>
    <div v-if="issues.length" class="issues"><article v-for="issue in issues" :key="issue"><span>!</span><p>{{ issue }}</p></article></div>
    <div v-else class="healthy-empty"><span>✓</span><div><strong>{{ t('projectHealthy') }}</strong><p>{{ t('projectHealthyHint') }}</p></div></div>
    <footer><button @click="openEditorTool('assets')">{{ t('assets') }}</button><button @click="openEditorTool('packages')">{{ t('packages') }}</button><button @click="openEditorTool('build')">{{ t('buildPanel') }}</button><button @click="state.currentPage = 'settings'">{{ t('projectSettings') }}</button></footer>
  </section>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import { t } from '../i18n'
import { assetState as assets } from '../assets/AssetDatabase'
import { buildAssetDependencyGraph } from '../assets/assetGraph'
import { buildSettings, validateBuildSettings } from '../runtime/buildSettings'
import { packageCompatibility, packageState as packages } from '../runtime/packages'
import { projectCompatibility } from '../projects/projectFormat'
import { getSceneJSON, sceneManager } from '../store/physics'
import { editorState as state } from '../store/editor'
import { openEditorTool } from '../editor/workspaces'
const compatibility = projectCompatibility()
const project = computed(() => { try { return JSON.parse(getSceneJSON()) as unknown } catch { return null } })
const graph = computed(() => buildAssetDependencyGraph(assets.records, project.value))
const buildIssues = computed(() => validateBuildSettings(buildSettings))
const packageProblems = computed(() => packages.installed.filter(item => item.project).flatMap(item => packageCompatibility(item).map(problem => `${item.manifest.name}: ${problem}`)))
const issues = computed(() => [...graph.value.missingReferences.slice(0, 8).map(item => `${t('missingReferences')}: ${item.reference}`), ...packageProblems.value, ...buildIssues.value.map(item => item.message)].slice(0, 16))
const summary = computed(() => issues.value.length ? t('issuesFound', { count: issues.value.length }) : t('healthy'))
const healthClass = computed(() => issues.value.length ? 'attention' : 'healthy')
</script>
<style scoped>
.project-health{height:100%;padding:10px;overflow:auto;background:var(--surface-1)}header{min-height:42px;display:flex;align-items:center;justify-content:space-between;gap:10px}header>div{display:grid}header small{color:var(--text-muted)}header>span{padding:4px 8px;border-radius:999px}.healthy{color:var(--success);background:color-mix(in srgb,var(--success) 12%,transparent)}.attention{color:var(--warning);background:color-mix(in srgb,var(--warning) 12%,transparent)}.health-grid{display:grid;grid-template-columns:repeat(6,minmax(120px,1fr));gap:7px}.health-grid article{padding:9px;display:grid;gap:3px;border:1px solid var(--border-subtle);border-radius:9px;background:var(--surface-2)}.health-grid span,.health-grid small{color:var(--text-muted)}.health-grid strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.issues{margin-top:9px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px}.issues article{min-width:0;padding:7px;display:flex;gap:7px;border-left:3px solid var(--warning);border-radius:7px;background:var(--surface-2)}.issues p{margin:0;overflow-wrap:anywhere}.healthy-empty{margin-top:10px;padding:12px;display:flex;align-items:center;gap:10px;border:1px solid color-mix(in srgb,var(--success) 40%,transparent);border-radius:10px;background:color-mix(in srgb,var(--success) 7%,transparent)}.healthy-empty>span{font-size:20px;color:var(--success)}.healthy-empty p{margin:2px 0 0;color:var(--text-muted)}footer{margin-top:9px;display:flex;gap:6px;flex-wrap:wrap}footer button{min-height:34px;padding:0 10px;border:1px solid var(--border-subtle);border-radius:8px;background:var(--surface-2)}@media(max-width:900px){.health-grid{grid-template-columns:repeat(3,minmax(120px,1fr))}}@media(max-width:560px){.health-grid,.issues{grid-template-columns:1fr 1fr}}
</style>
