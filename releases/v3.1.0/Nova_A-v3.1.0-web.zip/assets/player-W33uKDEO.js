import{ef as r,ee as a}from"./crashReporter-r9njtzCJ.js";import{K as p}from"./vue-runtime-DaH_spHj.js";import"./nova-runtime-Bes81QMv.js";r("Nova Player");p(a).mount("#app");
