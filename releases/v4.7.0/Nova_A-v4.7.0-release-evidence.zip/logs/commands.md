# Reproduction commands

`pnpm references:v4.7`

`pnpm audit:v4.7`

`pnpm verify:v4.7`

`pnpm qualify:v4.7:layout`

`cargo fmt --all -- --check`

`cargo clippy --workspace --all-targets -- -D warnings`

`cargo test --workspace --all-targets`

`pnpm build`

`pnpm tauri build`

`pnpm evidence:v4.7`
