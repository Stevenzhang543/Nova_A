import{gZ as r,gY as a}from"./crashReporter-B80v11Ye.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-8tgxOQ5h.js";r("Nova Player");p(a).mount("#app");
