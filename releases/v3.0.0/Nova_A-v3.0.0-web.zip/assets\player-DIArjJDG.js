import{e7 as r,e6 as a}from"./crashReporter-_u6WpYrG.js";import{K as p}from"./vue-runtime-DaH_spHj.js";import"./nova-runtime-DNDAoMjs.js";r("Nova Player");p(a).mount("#app");
