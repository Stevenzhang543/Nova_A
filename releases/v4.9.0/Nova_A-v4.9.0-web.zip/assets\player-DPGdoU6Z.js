import{h9 as r,h8 as a}from"./crashReporter-Bj0dLiUp.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-BOL49zOk.js";r("Nova Player");p(a).mount("#app");
