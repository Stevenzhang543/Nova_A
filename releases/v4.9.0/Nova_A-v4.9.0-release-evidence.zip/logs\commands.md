# Nova_A 4.9 reproduction commands

`pnpm references:v4.9`

`pnpm audit`

`pnpm security:v4.9`

`cargo fmt --all -- --check`

`cargo clippy --workspace --all-targets -- -D warnings`

`cargo test --workspace --all-targets`

`pnpm build`

`pnpm qualify:v4.9:layout`

`pnpm tauri build`

`pnpm verify:v4.9:windows`

`pnpm references:verify:v4.9`

`pnpm evidence:v4.9`

`powershell -File scripts/package-release.ps1 -Version 4.9.0`

`powershell -File scripts/verify-release-package.ps1 -Version 4.9.0`
