# Producing commands

- pnpm api:v2
- pnpm references:v4.6
- pnpm audit
- cargo fmt --all -- --check
- cargo clippy --workspace --all-targets -- -D warnings
- cargo test --workspace --all-targets
- pnpm build
- pnpm qualify:v4.6:layout
- pnpm tauri build
- pnpm verify:v4.6:windows
- pnpm evidence:v4.6
- scripts/package-release.ps1 -Version 4.6.0
- scripts/verify-release-package.ps1 -Version 4.6.0
