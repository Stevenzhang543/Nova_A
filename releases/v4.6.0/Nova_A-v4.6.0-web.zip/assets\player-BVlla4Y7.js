import{gK as r,gJ as a}from"./crashReporter-Dt-jtZOn.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-BCupyOom.js";r("Nova Player");p(a).mount("#app");
