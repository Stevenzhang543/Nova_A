import{g6 as r,g5 as a}from"./crashReporter-DNPtM2nZ.js";import{L as p}from"./vue-runtime-S12t7zDd.js";import"./nova-runtime-CDmirKvA.js";r("Nova Player");p(a).mount("#app");
