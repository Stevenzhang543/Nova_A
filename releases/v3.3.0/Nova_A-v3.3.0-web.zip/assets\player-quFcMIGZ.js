import{eM as r,eL as a}from"./crashReporter-vBhMXdSJ.js";import{K as p}from"./vue-runtime-us_q-wPr.js";import"./nova-runtime-MxheG1Gq.js";r("Nova Player");p(a).mount("#app");
