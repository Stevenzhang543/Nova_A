# Reproduction commands

`pnpm references:v4.8`

`pnpm audit`

`pnpm qualify:v4.8:layout`

`cargo fmt --all -- --check`

`cargo clippy --workspace --all-targets -- -D warnings`

`cargo test --workspace --all-targets`

`pnpm build`

`pnpm tauri build`

`pnpm verify:v4.8:windows`

`pnpm evidence:v4.8`
