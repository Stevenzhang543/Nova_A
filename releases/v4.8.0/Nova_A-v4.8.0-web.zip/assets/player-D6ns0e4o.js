import{h2 as r,h1 as a}from"./crashReporter-CDHuoqGu.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-CYYty9IA.js";r("Nova Player");p(a).mount("#app");
