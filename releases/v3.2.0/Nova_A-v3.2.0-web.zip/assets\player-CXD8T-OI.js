import{ez as r,ey as a}from"./crashReporter-BtAIMaxD.js";import{K as p}from"./vue-runtime-DaH_spHj.js";import"./nova-runtime-BjcIRnkt.js";r("Nova Player");p(a).mount("#app");
