import{h9 as r,h8 as a}from"./crashReporter-DqOx8UTY.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-BF8t-xsY.js";r("Nova Player");p(a).mount("#app");
