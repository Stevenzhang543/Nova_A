import{fj as r,fi as a}from"./crashReporter-s-p4-i2U.js";import{L as p}from"./vue-runtime-1sAgQeXI.js";import"./nova-runtime-BxQukWBJ.js";r("Nova Player");p(a).mount("#app");
