# Shader and Typed Uniforms

Engine **3.8.0**, Project Format 2, schema 28.

Demonstrates: typed reflected shader uniforms, includes, variants and compile cache, source-linked safe-shader diagnostics and material serialization.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/rendering-shader-uniforms/project.nova --target web --profile release --output ./Builds/reference-rendering-shader-uniforms
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
