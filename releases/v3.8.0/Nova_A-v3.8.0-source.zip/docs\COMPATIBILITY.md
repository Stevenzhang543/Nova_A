# Compatibility and migration policy

Nova_A 3.8.0 writes Project Format 2, schema 28, engine version 3.8.0. It accepts every publicly supported schema from 5 through 28. Schema 24 added named physics layers and production physics; schema 25 added stable Rhai API v1; schema 26 added the presentation layer; schema 27 added the visual/audio pipeline; schema 28 additively upgrades TileSets, tile layers, navigation, streaming-cell and pool data. Migration preserves collision bits, masks, scripts, presentation, authored custom strokes, tile data and compatible unknown fields; older readers must use the pre-migration backup because they cannot safely edit schema 28.

Import is transactional:

1. Parse and bound the selected file.
2. Route a newer major/schema to the non-mutating read-only compatibility viewer before editor state changes.
3. Produce a migration preview and package compatibility report.
4. Offer the untouched source as a rollback download and retain a local rollback copy when storage allows.
5. Migrate in memory, validate the complete document, serialize/reparse it, and only then replace the session.

The golden matrix in `tests/fixtures/migrations/` covers schemas 5–27 and checks the schema target, active scene, scene/entity counts, compatibility metadata, engine version, unknown-field preservation, physics-layer bit preservation, script metadata, visual/audio/world-data defaults, and post-serialization validation. Deterministic corrupted-input mutations verify that import does not panic. The legacy `v1_1_2_project.json` fixture remains as an additional real historical sample.

Packages and plugins are audited before activation. A project can be opened with an incompatible optional package disabled; its manifest and serialized data stay present so repairing the dependency does not lose data.

Downgrading a schema-28 project into an older Nova_A version is not supported. Use the automatic pre-upgrade backup to return to the original file. See `PROJECT_FORMAT_2_SCHEMA_28.md` for world-data fields, `PROJECT_FORMAT_2_SCHEMA_27.md` for visual/audio fields, and `PROJECT_FORMAT_2_SCHEMA_24.md` for physics.
