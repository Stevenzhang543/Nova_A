# Nova_A Pseudolocalization Stress

Engine **3.8.0**, Project Format 2, schema 28.

Demonstrates: 35% string expansion, clipping and missing-key audit.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/pseudoloc-stress/project.nova --target web --profile release --output ./Builds/reference-pseudoloc-stress
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
