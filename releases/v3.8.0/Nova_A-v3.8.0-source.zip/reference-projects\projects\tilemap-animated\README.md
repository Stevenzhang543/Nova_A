# Animated and Metadata Tiles

Engine **3.8.0**, Project Format 2, schema 28.

Demonstrates: animated tiles, custom metadata, scene/prefab placement fields, atlas sources.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/tilemap-animated/project.nova --target web --profile release --output ./Builds/reference-tilemap-animated
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
