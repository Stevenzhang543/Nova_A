# Terrain Rules and Validation

Engine **3.8.0**, Project Format 2, schema 28.

Demonstrates: complete 16-mask terrain rules, weighted deterministic variants, terrain validation and preview.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/tilemap-terrain-rules/project.nova --target web --profile release --output ./Builds/reference-tilemap-terrain-rules
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
