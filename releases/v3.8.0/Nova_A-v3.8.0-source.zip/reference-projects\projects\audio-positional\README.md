# Positional Audio

Engine **3.8.0**, Project Format 2, schema 28.

Demonstrates: 2D listener, panning and distance attenuation, polyphony, deterministic pitch/volume variation, voice priority and limits.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/audio-positional/project.nova --target web --profile release --output ./Builds/reference-audio-positional
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
