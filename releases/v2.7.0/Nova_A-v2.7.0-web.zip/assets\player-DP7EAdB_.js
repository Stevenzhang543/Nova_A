import{V as r}from"./main-DQeeq4A3.js";import{d7 as a,d8 as p}from"./crash-reporter-CfydT46x.js";import"./nova-runtime-CIy4ToQx.js";a("Nova Player");p(r).mount("#app");
