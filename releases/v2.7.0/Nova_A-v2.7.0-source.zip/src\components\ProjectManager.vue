<template>
  <main class="project-manager">
    <header class="manager-header">
      <a class="identity" href="https://whitelists.top" target="_blank" rel="noreferrer"><span>N</span><strong>Nova_A</strong></a>
      <nav aria-label="Project manager utilities">
        <select v-model="prefs.locale" :aria-label="t('language')"><option value="en">English</option><option value="de">Deutsch</option><option value="zh">中文</option></select>
        <button class="manual-link" type="button" @click="openBundledManual">{{ t('manual') }}</button>
        <span class="version">2.7.0</span>
      </nav>
    </header>

    <section class="manager-shell">
      <div class="welcome">
        <span class="eyebrow">{{ t('projectFormatTwo') }}</span>
        <h1>{{ t('createSomethingPlayable') }}</h1>
        <p>{{ t('projectManagerDescription') }}</p>
        <div class="quick-actions">
          <button class="primary" :disabled="state.busy" @click="openInput?.click()">{{ t('openProject') }}</button>
          <button :disabled="state.busy" @click="importInput?.click()">{{ t('importProject') }}</button>
          <button v-if="state.currentSnapshot" :disabled="state.busy" @click="continueCurrentProject">{{ t('continueProject') }}</button>
        </div>
        <p v-if="state.error" class="error" role="alert">{{ state.error }}</p>
      </div>

      <section class="creation-card">
        <header><div><span>{{ t('newProject') }}</span><strong>{{ projectName || t('untitledProject') }}</strong></div><label>{{ t('projectName') }}<input v-model="projectName" maxlength="80" @keydown.enter="create"></label></header>
        <div class="template-grid">
          <button v-for="template in templates" :key="template.id" :class="{ selected: selectedTemplate === template.id }" @click="selectedTemplate = template.id">
            <span class="template-icon">{{ icons[template.id] }}</span>
            <strong>{{ templateName(template.id, template.name) }}</strong>
            <small>{{ templateDescription(template.id, template.description) }}</small>
            <span class="feature-list">{{ template.features.join(' · ') }}</span>
          </button>
        </div>
        <button class="create-button" :disabled="state.busy" @click="create">{{ state.busy ? t('preparingProject') : t('createProject') }}</button>
      </section>

      <section class="recents-card">
        <header><div><span>{{ t('recentProjects') }}</span><strong>{{ state.recents.length }}</strong></div><small>{{ t('recentProjectsHint') }}</small></header>
        <div v-if="state.recents.length" class="recent-list">
          <article v-for="recent in state.recents" :key="recent.id">
            <button class="recent-main" :disabled="state.busy || !recent.snapshot" @click="openRecentProject(recent.id)">
              <span class="recent-mark">{{ recent.name.slice(0, 1).toUpperCase() }}</span>
              <span><strong>{{ recent.name }}</strong><small>{{ recent.template }} · {{ formatDate(recent.updatedAt) }}</small></span>
              <em>{{ recent.snapshot ? t('open') : t('selectFileRequired') }}</em>
            </button>
            <button class="remove-recent" :aria-label="t('removeRecent')" @click="removeRecentProject(recent.id)">×</button>
          </article>
        </div>
        <p v-else class="empty-recents">{{ t('noRecentProjects') }}</p>
      </section>
    </section>

    <footer><span>{{ t('managerFooter') }}</span><a href="https://github.com/Stevenzhang543/Nova_A/" target="_blank" rel="noreferrer">GitHub</a></footer>
    <input ref="openInput" hidden type="file" accept=".nova,.json,application/json" @change="readFile($event, false)">
    <input ref="importInput" hidden type="file" accept=".nova,.json,application/json" @change="readFile($event, true)">
  </main>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { t } from '../i18n'
import { preferencesState as prefs } from '../store/preferences'
import { continueCurrentProject, createNewProject, openProjectDocument, openRecentProject, projectManagerState as state, removeRecentProject } from '../projects/projectManager'
import { PROJECT_TEMPLATES as templates, type ProjectTemplateId } from '../projects/templates'
import { openBundledManual } from '../runtime/openManual'

const projectName = ref('My Game')
const selectedTemplate = ref<ProjectTemplateId>('empty')
const openInput = ref<HTMLInputElement | null>(null)
const importInput = ref<HTMLInputElement | null>(null)
const icons: Record<ProjectTemplateId, string> = { empty: '◇', platformer: '▰', 'top-down': '◉', 'physics-sandbox': '⌁' }

function templateName(id: ProjectTemplateId, fallback: string): string { return t(`template_${id}_name`) || fallback }
function templateDescription(id: ProjectTemplateId, fallback: string): string { return t(`template_${id}_description`) || fallback }
function create(): void { void createNewProject(projectName.value, selectedTemplate.value) }
function formatDate(value: string): string { const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleString(prefs.locale === 'zh' ? 'zh-CN' : prefs.locale) }

function readFile(event: Event, asCopy: boolean): void {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = () => { if (typeof reader.result === 'string') void openProjectDocument(reader.result, file.name, asCopy) }
  reader.onerror = () => { state.error = reader.error?.message ?? t('fileReadFailed') }
  reader.readAsText(file)
  input.value = ''
}
</script>

<style scoped>
.project-manager { min-height: 100vh; display: flex; flex-direction: column; color: var(--text-primary); background: radial-gradient(circle at 12% 8%, var(--accent-soft), transparent 31%), linear-gradient(145deg, var(--bg-base), var(--surface-1)); overflow: auto; }
.manager-header { min-height: 56px; padding: 0 clamp(18px, 4vw, 52px); display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border-subtle); background: color-mix(in srgb, var(--surface-1) 82%, transparent); backdrop-filter: blur(18px); position: sticky; top: 0; z-index: 2; }
.identity { display: flex; align-items: center; gap: 10px; color: inherit; text-decoration: none; }.identity span { width: 29px; height: 29px; display: grid; place-items: center; border-radius: 9px; color: var(--accent-contrast); background: linear-gradient(145deg, var(--accent), var(--accent-strong)); box-shadow: 0 7px 20px var(--accent-soft); }.identity strong { font-size: 15px; letter-spacing: -.02em; }
.manager-header nav { display: flex; align-items: center; gap: 8px; }.manager-header select, .manager-header a, .manager-header .manual-link, .version { min-height: 30px; padding: 0 10px; display: inline-flex; align-items: center; border: 1px solid var(--border-subtle); border-radius: 8px; color: var(--text-secondary); background: var(--surface-2); font-size: 10px; text-decoration: none; }.manager-header .manual-link { cursor: pointer; }.version { color: var(--accent); }
.manager-shell { width: min(1180px, calc(100% - 32px)); margin: auto; padding: 52px 0; display: grid; grid-template-columns: minmax(250px, .72fr) minmax(520px, 1.55fr); gap: 18px; }.welcome { padding: 26px 10px 20px 0; }.eyebrow, .creation-card header span, .recents-card header span { color: var(--accent); font-size: 10px; font-weight: 750; letter-spacing: .09em; text-transform: uppercase; }.welcome h1 { max-width: 480px; margin: 13px 0 12px; font-size: clamp(34px, 5vw, 62px); line-height: .98; letter-spacing: -.055em; }.welcome > p { max-width: 470px; color: var(--text-muted); font-size: 12px; line-height: 1.65; }.quick-actions { margin-top: 24px; display: flex; flex-wrap: wrap; gap: 8px; }.quick-actions button, .create-button { min-height: 38px; padding: 0 15px; border: 1px solid var(--border-strong); border-radius: 10px; color: var(--text-secondary); background: var(--surface-2); font-size: 11px; }.quick-actions .primary, .create-button { color: var(--accent-contrast); border-color: var(--accent); background: var(--accent); }.error { padding: 10px 12px; border: 1px solid var(--danger); border-radius: 10px; color: var(--danger) !important; background: var(--danger-soft); }
.creation-card, .recents-card { border: 1px solid var(--border-subtle); border-radius: 18px; background: color-mix(in srgb, var(--surface-1) 91%, transparent); box-shadow: var(--shadow-md); overflow: hidden; }.creation-card { grid-row: span 2; padding: 18px; }.creation-card header { display: flex; align-items: end; justify-content: space-between; gap: 16px; }.creation-card header div { display: flex; flex-direction: column; gap: 5px; }.creation-card header strong { font-size: 16px; }.creation-card label { width: min(250px, 48%); display: flex; flex-direction: column; gap: 4px; color: var(--text-muted); font-size: 9px; }.creation-card input { min-height: 32px; }
.template-grid { margin-top: 16px; display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }.template-grid button { min-height: 150px; padding: 15px; display: flex; flex-direction: column; align-items: flex-start; gap: 7px; border: 1px solid var(--border-subtle); border-radius: 13px; color: var(--text-primary); background: var(--surface-2); text-align: left; }.template-grid button:hover, .template-grid button.selected { transform: translateY(-2px); border-color: var(--accent); background: var(--accent-soft); box-shadow: 0 10px 28px color-mix(in srgb, var(--accent) 12%, transparent); }.template-icon { width: 34px; height: 34px; display: grid; place-items: center; border-radius: 10px; color: var(--accent); background: var(--surface-3); font-size: 20px; }.template-grid strong { font-size: 12px; }.template-grid small { color: var(--text-muted); font-size: 9.5px; line-height: 1.45; }.feature-list { margin-top: auto; color: var(--accent); font-size: 8px; }.create-button { width: 100%; margin-top: 12px; }
.recents-card { grid-column: 1; padding: 16px; }.recents-card header { display: flex; align-items: end; justify-content: space-between; gap: 10px; }.recents-card header div { display: flex; align-items: baseline; gap: 8px; }.recents-card header strong { font-size: 17px; }.recents-card header small { max-width: 190px; color: var(--text-muted); font-size: 8px; text-align: right; }.recent-list { margin-top: 12px; display: grid; gap: 6px; }.recent-list article { display: grid; grid-template-columns: 1fr 28px; gap: 4px; }.recent-main { min-width: 0; min-height: 48px; padding: 5px 8px; display: grid; grid-template-columns: 32px minmax(0, 1fr) auto; align-items: center; gap: 8px; border: 1px solid transparent; border-radius: 9px; color: var(--text-primary); background: var(--surface-2); text-align: left; }.recent-main:hover { border-color: var(--accent); background: var(--accent-soft); }.recent-main > span:nth-child(2) { min-width: 0; display: flex; flex-direction: column; }.recent-main strong, .recent-main small { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }.recent-main strong { font-size: 10px; }.recent-main small { color: var(--text-muted); font-size: 8px; }.recent-main em { color: var(--accent); font-size: 8px; font-style: normal; }.recent-mark { width: 30px; height: 30px; display: grid; place-items: center; border-radius: 8px; color: var(--accent); background: var(--accent-soft); }.remove-recent { border: 0; border-radius: 7px; color: var(--text-muted); background: transparent; }.remove-recent:hover { color: var(--danger); background: var(--danger-soft); }.empty-recents { margin: 14px 0 0; color: var(--text-muted); font-size: 9.5px; }.project-manager footer { min-height: 42px; padding: 0 clamp(18px, 4vw, 52px); display: flex; align-items: center; justify-content: space-between; color: var(--text-muted); border-top: 1px solid var(--border-subtle); font-size: 9px; }.project-manager footer a { color: var(--accent); text-decoration: none; }
@media (max-width: 900px) { .manager-shell { grid-template-columns: 1fr; padding: 28px 0; }.welcome { padding: 10px 0; }.creation-card { grid-row: auto; }.recents-card { grid-column: auto; }.welcome h1 { font-size: 40px; } }
@media (max-width: 580px) { .manager-header { padding: 0 12px; }.identity strong, .version { display: none; }.manager-shell { width: min(100% - 20px, 560px); }.creation-card header { align-items: stretch; flex-direction: column; }.creation-card label { width: 100%; }.template-grid { grid-template-columns: 1fr; }.template-grid button { min-height: 126px; } }
.manager-header select, .manager-header a, .manager-header .manual-link, .version { min-height: 32px; font-size: 12px; }
.eyebrow, .creation-card header span, .recents-card header span { font-size: 11px; }
.welcome > p { font-size: 14px; }.quick-actions button, .create-button { min-height: 40px; font-size: 12px; }
.creation-card label { font-size: 11px; }.creation-card input { min-height: 34px; }
.template-grid strong { font-size: 13px; }.template-grid small { font-size: 11px; }.feature-list { font-size: 10px; }
.recents-card header small, .recent-main small, .recent-main em { font-size: 10px; }.recent-main { min-height: 52px; }.recent-main strong { font-size: 11px; }
.empty-recents, .project-manager footer { font-size: 11px; }
</style>
