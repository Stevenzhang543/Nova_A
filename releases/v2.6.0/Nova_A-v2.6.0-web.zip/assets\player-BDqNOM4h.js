import{R as r}from"./main-Bckv5JCV.js";import{c$ as a,d0 as p}from"./crash-reporter-DNdzX6Pq.js";import"./nova-runtime-DJJAEAfd.js";a("Nova Player");p(r).mount("#app");
