# 5,000 Object Authoring Stress

Engine **3.6.0**, Project Format 2, schema 26.

Demonstrates: 5,000 objects, performance mode, component and tag search, box selection.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/authoring-5000-stress/project.nova --target web --profile release --output ./Builds/reference-authoring-5000-stress
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
