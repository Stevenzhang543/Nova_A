import{f2 as r,f1 as a}from"./crashReporter-CMlQwn7t.js";import{L as p}from"./vue-runtime-1sAgQeXI.js";import"./nova-runtime-DUOV6P8A.js";r("Nova Player");p(a).mount("#app");
