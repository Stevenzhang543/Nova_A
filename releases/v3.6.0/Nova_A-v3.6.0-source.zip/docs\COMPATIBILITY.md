# Compatibility and migration policy

Nova_A 3.6.0 writes Project Format 2, schema 26, engine version 3.6.0. It accepts every publicly supported schema from 5 through 26. Schema 24 added named physics layers and production physics; schema 25 added the stable Rhai API v1 contract; schema 26 additively normalizes responsive UI, structured localization, multi-device input bindings, UI audio references, and runtime accessibility preferences. Migration preserves every collision bit, mask, script source, presentation setting, and compatible unknown field; older readers must use the pre-migration backup because they cannot safely edit schema 26.

Import is transactional:

1. Parse and bound the selected file.
2. Route a newer major/schema to the non-mutating read-only compatibility viewer before editor state changes.
3. Produce a migration preview and package compatibility report.
4. Offer the untouched source as a rollback download and retain a local rollback copy when storage allows.
5. Migrate in memory, validate the complete document, serialize/reparse it, and only then replace the session.

The golden matrix in `tests/fixtures/migrations/` covers schemas 5–25 and checks the schema target, active scene, scene/entity counts, compatibility metadata, engine version, unknown-field preservation, physics-layer bit preservation, script metadata, and post-serialization validation. Deterministic corrupted-input mutations verify that import does not panic. The legacy `v1_1_2_project.json` fixture remains as an additional real historical sample.

Packages and plugins are audited before activation. A project can be opened with an incompatible optional package disabled; its manifest and serialized data stay present so repairing the dependency does not lose data.

Downgrading a schema-25 project into an older Nova_A version is not supported. Use the automatic pre-upgrade backup to return to the original file. See `PROJECT_FORMAT_2_SCHEMA_25.md` for the current scripting fields and `PROJECT_FORMAT_2_SCHEMA_24.md` for the retained physics migration.
