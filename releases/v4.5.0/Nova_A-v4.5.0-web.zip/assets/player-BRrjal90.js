import{gD as r,gC as a}from"./crashReporter-DqizEplv.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-ChRwz6au.js";r("Nova Player");p(a).mount("#app");
