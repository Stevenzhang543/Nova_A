# Producing commands

- pnpm audit:v4.5
- pnpm verify:v4.5
- cargo test --workspace --all-targets
- pnpm build
- pnpm qualify:v4.5:layout
- pnpm tauri build
- pnpm verify:v4.5:windows
- pnpm evidence:v4.5
- scripts/package-release.ps1 -Version 4.5.0
- scripts/verify-release-package.ps1 -Version 4.5.0
