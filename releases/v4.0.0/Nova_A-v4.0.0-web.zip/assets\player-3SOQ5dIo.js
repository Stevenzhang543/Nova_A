import{fC as r,fB as a}from"./crashReporter-CvuozWaT.js";import{L as p}from"./vue-runtime-1sAgQeXI.js";import"./nova-runtime-DB6wOFbW.js";r("Nova Player");p(a).mount("#app");
