import{eY as r,eX as a}from"./crashReporter-DPkkqZdv.js";import{K as p}from"./vue-runtime-us_q-wPr.js";import"./nova-runtime-MOMf7L99.js";r("Nova Player");p(a).mount("#app");
