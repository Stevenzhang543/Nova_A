# Nova_A API v1 Examples

Engine **3.5.0**, Project Format 2, schema 25.

Demonstrates: API v1 handles, input, physics, animation, audio, navigation, save and resources.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/script-api-v1-examples/project.nova --target web --profile release --output ./Builds/reference-script-api-v1-examples
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
