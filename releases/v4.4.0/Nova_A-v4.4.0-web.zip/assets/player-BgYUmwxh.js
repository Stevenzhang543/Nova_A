import{gy as r,gx as a}from"./crashReporter-BMulvvTI.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-CWM9bV57.js";r("Nova Player");p(a).mount("#app");
