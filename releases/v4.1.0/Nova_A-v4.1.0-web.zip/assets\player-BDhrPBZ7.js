import{fC as r,fB as a}from"./crashReporter-Dp9QcNqa.js";import{L as p}from"./vue-runtime-S12t7zDd.js";import"./nova-runtime-CQpfe_iN.js";r("Nova Player");p(a).mount("#app");
