import{gi as r,gh as a}from"./crashReporter-BS8i2hhm.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-Cyc3qfhz.js";r("Nova Player");p(a).mount("#app");
