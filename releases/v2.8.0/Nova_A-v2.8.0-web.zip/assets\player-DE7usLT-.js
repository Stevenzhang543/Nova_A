import{a7 as a}from"./main-Cif4VruD.js";import{dd as r,de as p}from"./crash-reporter-BNeOsBOV.js";import"./nova-runtime-sRa9OITx.js";r("Nova Player");p(a).mount("#app");
