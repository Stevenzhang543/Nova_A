# Nova_A 3.6 known limitations

Nova_A is deliberately a professional 2D-first engine. It does not include built-in 3D rendering/physics, ray tracing, VR/XR, AAA terrain or foliage, cinematic virtual-production tools, or proprietary console SDKs.

Lighting, rigging, behavior/navigation tools, networking, Android support, and third-party integrations can remain official optional packages. Projects that do not reference an optional package do not load or serialize its runtime state.

Other release boundaries:

- Native packages are never downloaded or executed by the package browser; users install trusted native tools externally.
- API 1 plugins are compatibility-only and cannot request API 2 editor/runtime capabilities.
- Native export is host-oriented. Cross-platform bundles are built on their target OS in the release matrix.
- macOS distribution still needs publisher signing/notarization; Android distribution needs a user-owned SDK/JDK/keystore.
- The locally produced Windows EXE/MSI/NSIS artifacts are not Authenticode-signed because no Whitelist publisher certificate was provided. Their SHA-256 hashes are published, but Windows may show a SmartScreen/unverified-publisher prompt until the release is signed.
- Console export needs the platform holder's SDK and agreement and is not included.
- Web performance depends on browser/WebGL2/WebAssembly support; Canvas2D is a functional fallback with different throughput.
- The included networking sample is opt-in infrastructure, not a managed matchmaking, relay, anti-cheat, or account service.
- Nova_A 3.6 does not integrate Tauri's updater plugin or publish updater signatures. Windows releases use the complete MSI/NSIS installers; the Tauri bundle-type marker warning therefore does not affect the shipped install path. Requalify it before adding automatic updates.
- Tier-1 web game accessibility uses DOM/ARIA names, descriptions, roles, states, values, focus, and live-region hooks. Native operating-system screen-reader bridges still require adapters and qualification per desktop target.
- The v3 headless benchmark does not claim interactive native startup, memory, or GPU frame-time results until reference-machine evidence is attached.
- Chain and concave-polygon colliders are available for authoring and queries, but are labelled query-only and are not submitted to the dynamic solver. Capsule and finite-segment colliders are native deterministic convex shapes.
- Multiple local collider shapes currently share one rigid transform and are reduced to a deterministic convex envelope for native dynamics. Individual local shapes remain editable and round-trip exactly.
- The included twelve-hour physics report advances exactly 2,592,000 fixed ticks (twelve simulated hours at 60 Hz) in an optimized process. It is accelerated-time stability evidence, not a twelve-hour wall-clock qualification.
- Rhai step into/over/out pauses at safe callback boundaries; arbitrary statement-level suspension is not exposed by the embedded VM adapter. Line/function/conditional/log breakpoints, source frames, watches, evaluation, and break-on-error remain supported.
- Per-script allocation values are deterministic estimates because the Rhai allocator does not expose exact allocation telemetry. Calls and duration counters are measured.
- The external editor adapter implements the documented `nova-rhai-language/1` JSON-lines stdio protocol; it is not advertised as a complete Language Server Protocol implementation.
