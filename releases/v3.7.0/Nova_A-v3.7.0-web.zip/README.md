# Nova_A 3.7.0 Web Package

Serve this directory from an HTTP(S) origin. Do not open index.html with ile://; WebAssembly modules, workers, ES modules, and the bundled manual require a web server. index.html opens the editor and player.html opens the standalone player. Preserve file names and MIME types, especially pplication/wasm for .wasm files. HTTPS is required for production networking and other secure browser APIs.

Verify every packaged file against SHA256SUMS.txt. Release metadata is in elease-metadata.json.