import{f9 as r,f8 as a}from"./crashReporter-BTcKvYtm.js";import{L as p}from"./vue-runtime-1sAgQeXI.js";import"./nova-runtime-owI6woZm.js";r("Nova Player");p(a).mount("#app");
