# Resolution Independent Authoring

Engine **3.7.0**, Project Format 2, schema 27.

Demonstrates: world-unit scaling, common-resolution overlays, vector shapes, camera aspect previews.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/authoring-resolution-independent/project.nova --target web --profile release --output ./Builds/reference-authoring-resolution-independent
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
