# Nova_A Debugger Scenarios

Engine **3.7.0**, Project Format 2, schema 27.

Demonstrates: line/function/conditional/hit-count breakpoints, logpoints, locals, watches and callback stacks.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm export -- --project ./reference-projects/projects/script-debugger-scenarios/project.nova --target web --profile release --output ./Builds/reference-script-debugger-scenarios
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
