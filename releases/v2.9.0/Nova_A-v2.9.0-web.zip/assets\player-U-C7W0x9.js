import{a7 as a}from"./main-h2CsK4fi.js";import{dB as r,dC as p}from"./crash-reporter-xEOK3BKh.js";import"./nova-runtime-BNEIfMFB.js";r("Nova Player");p(a).mount("#app");
