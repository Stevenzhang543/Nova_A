import{h9 as r,h8 as a}from"./crashReporter-CDYKwqhH.js";import{L as p}from"./vue-runtime-ZsYitA6g.js";import"./nova-runtime-CY5IXKQV.js";r("Nova Player");p(a).mount("#app");
