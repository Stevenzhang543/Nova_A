# Nova_A 5.0 reproduction commands

`pnpm references:v5.0`

`pnpm audit`

`pnpm security:v5.0`

`cargo fmt --all -- --check`

`cargo clippy --workspace --all-targets -- -D warnings`

`cargo test --workspace --all-targets`

`pnpm build`

`pnpm qualify:v5.0:layout`

`pnpm tauri build`

`pnpm verify:v5.0:windows`

`pnpm references:verify:v5.0`

`pnpm reproducibility:v5.0`

`pnpm benchmark:v5.0`

`pnpm stability:v5.0`

`pnpm evidence:v5.0`

`powershell -File scripts/package-release.ps1 -Version 5.0.0`

`powershell -File scripts/verify-release-package.ps1 -Version 5.0.0`
