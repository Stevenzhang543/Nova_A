import{eT as r,eS as a}from"./crashReporter-CBj85Q9z.js";import{K as p}from"./vue-runtime-us_q-wPr.js";import"./nova-runtime-CMhJrKCZ.js";r("Nova Player");p(a).mount("#app");
