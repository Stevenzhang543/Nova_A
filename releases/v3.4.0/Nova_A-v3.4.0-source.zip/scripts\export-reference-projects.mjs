import { createHash } from 'node:crypto'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createServer } from 'vite'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const output = join(root, 'reference-projects')
const projectsDirectory = join(output, 'projects')
const pluginsDirectory = join(output, 'plugins', 'hello-plugin')
await mkdir(projectsDirectory, { recursive: true })
await mkdir(pluginsDirectory, { recursive: true })

function normalizeProjectAssets(project) {
  for (const asset of project.assets ?? []) {
    const source = typeof asset.source === 'string' ? asset.source : ''
    const hash = createHash('sha256').update(source).digest('hex')
    asset.pipeline = {
      importerVersion: asset.pipeline?.importerVersion ?? `nova-${asset.assetType ?? 'asset'}-3.4`,
      platform: asset.pipeline?.platform ?? 'web',
      sourceHash: asset.pipeline?.sourceHash ?? hash,
      artifactHash: asset.pipeline?.artifactHash ?? hash,
      contentHash: asset.pipeline?.contentHash ?? hash,
      cacheKey: asset.pipeline?.cacheKey ?? hash,
      dependencies: asset.pipeline?.dependencies ?? [],
      reverseDependencies: asset.pipeline?.reverseDependencies ?? [],
    }
  }
  return project
}

async function writeProjectBundle(slug, project, demonstrates) {
  normalizeProjectAssets(project)
  const directory = join(projectsDirectory, slug)
  await mkdir(directory, { recursive: true })
  const source = `${JSON.stringify(project, null, 2)}\n`
  await writeFile(join(directory, 'project.nova'), source, 'utf8')
  const entityCount = (project.scenes ?? []).reduce((total, scene) => total + (scene.entities?.length ?? 0), 0)
  await writeFile(join(directory, 'expected-output.json'), `${JSON.stringify({ engineVersion: '3.4.0', schema: 24, projectName: project.projectMetadata?.name ?? project.name ?? slug, minimumScenes: project.scenes?.length ?? 0, minimumEntities: entityCount, expectedValidation: slug === 'data-foundation-validation' ? 'repair-required' : 'pass', demonstrates }, null, 2)}\n`, 'utf8')
  await writeFile(join(directory, 'test-controls.json'), `${JSON.stringify({ open: 'Project Manager > Open Project > project.nova', run: 'Top action bar > Play; Pause; Step; Stop', validate: 'Project Health must report no blocking project-format error', export: 'Build Settings > Overview > Build', command: `pnpm export -- --project ./reference-projects/projects/${slug}/project.nova --target web --profile release --output ./Builds/reference-${slug}` }, null, 2)}\n`, 'utf8')
  await writeFile(join(directory, 'README.md'), `# ${project.projectMetadata?.name ?? slug}\n\nEngine **3.4.0**, Project Format 2, schema 24.\n\nDemonstrates: ${demonstrates.join(', ')}.\n\n1. Open \`project.nova\` from Project Manager.\n2. Confirm Project Health has no blocking format error.\n3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with \`expected-output.json\`.\n4. Run the validation export:\n\n\`\`\`powershell\npnpm export -- --project ./reference-projects/projects/${slug}/project.nova --target web --profile release --output ./Builds/reference-${slug}\n\`\`\`\n\nThe exact keyboard and UI controls are recorded in \`test-controls.json\`.\n`, 'utf8')
}

if (!globalThis.btoa) globalThis.btoa = value => Buffer.from(value, 'binary').toString('base64')
const server = await createServer({ root, appType: 'custom', logLevel: 'silent', server: { middlewareMode: true } })
try {
  const { PROJECT_TEMPLATES, createTemplateProject } = await server.ssrLoadModule('/src/projects/templates.ts')
  for (const descriptor of PROJECT_TEMPLATES) {
    const project = createTemplateProject(descriptor.id, `Nova_A ${descriptor.name} Reference`)
    normalizeProjectAssets(project)
    await writeFile(join(projectsDirectory, `${descriptor.id}.nova`), `${JSON.stringify(project, null, 2)}\n`, 'utf8')
    await writeProjectBundle(descriptor.id, project, descriptor.features)
  }
  const physicsReferences = [
    ['platformer-character', 'platformer', ['character slopes and steps', 'moving platform behavior', 'floor/wall/ceiling contacts']],
    ['top-down-character', 'top-down', ['top-down character motion', 'triggers', 'named collision layers']],
    ['joint-showcase', 'physics-sandbox', ['distance, revolute, prismatic, weld, spring, rope and motor joints', 'limits and break thresholds']],
    ['trigger-showcase', 'top-down', ['trigger enter, stay and exit', 'stable contact data order']],
    ['ccd-test', 'physics-sandbox', ['continuous collision detection', 'thin-wall tunneling reference']],
    ['stacking-test', 'physics-sandbox', ['stable stacks', 'friction, restitution, sleep and wake']]
  ]
  for (const [slug, template, features] of physicsReferences) {
    const title = slug.split('-').map(word => word[0].toUpperCase() + word.slice(1)).join(' ')
    const project = createTemplateProject(template, `Nova_A ${title}`)
    if (slug === 'ccd-test') for (const scene of project.scenes ?? []) for (const entity of scene.entities ?? []) for (const component of entity.components ?? []) if (component.kind === 'RigidBody2D') component.data.continuousCollision = 'Continuous'
    await writeProjectBundle(slug, project, features)
  }
  const recoveryProject = createTemplateProject('empty', 'Workspace and Recovery Validation')
  normalizeProjectAssets(recoveryProject)
  await writeFile(join(projectsDirectory, 'workspace-recovery-validation.nova'), `${JSON.stringify(recoveryProject, null, 2)}\n`, 'utf8')
  await writeProjectBundle('workspace-recovery-validation', recoveryProject, ['workspace import/export', 'docking', '100-step history', 'autosave recovery', 'safe layout', 'read-only recovery'])
} finally {
  await server.close()
}

const dataFoundationSource = await readFile(join(projectsDirectory, 'data-foundation-validation.nova'), 'utf8')
await writeProjectBundle('data-foundation-validation', JSON.parse(dataFoundationSource), ['manifest and directory policy', 'nested scenes', 'nested prefabs', 'per-property overrides', 'imported artifact hashes', 'dependency graph', 'missing-resource repair'])

const baseAuthoringProject = JSON.parse(await readFile(join(projectsDirectory, 'empty.nova'), 'utf8'))
const stableUuid = seed => {
  const hex = createHash('sha256').update(seed).digest('hex').slice(0, 32)
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-8${hex.slice(17, 20)}-${hex.slice(20)}`
}
const authoringComponent = (seed, kind, data = {}) => ({ uuid: stableUuid(`${seed}:${kind}`), kind, enabled: true, removed: false, data })
const authoredEntity = (seed, kind, x, y, options = {}) => {
  const transform = authoringComponent(seed, 'Transform2D', { parentUuid: options.parentUuid ?? null, position: { x, y }, rotation: options.rotation ?? 0, scale: options.scale ?? { x: 1, y: 1 } })
  const components = [transform]
  if (kind === 'Camera') components.push(authoringComponent(seed, 'Camera2D', { active: true, orthographicSize: options.orthographicSize ?? 10, viewport: options.viewport ?? { x: 0, y: 0, width: 1, height: 1 }, backgroundColor: { r: 17, g: 21, b: 27 }, pixelPerfect: options.pixelPerfect === true, zoom: options.zoom ?? 1, smoothing: { enabled: false, speed: 5 }, limits: { enabled: false, left: -100, right: 100, bottom: -100, top: 100 }, dragMargins: { enabled: false, left: .1, right: .1, top: .1, bottom: .1 }, previewInEditor: true, priority: options.priority ?? 0, stackOrder: options.priority ?? 0, cullingMask: 0xffffffff, clearColor: true }))
  else if (kind === 'WorldText') components.push(authoringComponent(seed, 'TextRenderer2D', { text: options.name ?? 'Resolution independent text', fontAsset: null, fontFamily: 'Nunito Sans', fontSize: 1, fontWeight: 600, lineHeight: 1.2, align: 'center', color: options.color ?? { r: 235, g: 242, b: 255 }, opacity: 100, maxWidth: 12, sortingLayer: options.layer ?? 1, orderInLayer: options.order ?? 0, material: 'Default' }))
  else if (kind === 'Sprite') components.push(authoringComponent(seed, 'SpriteRenderer2D', { spriteAsset: options.spriteAsset ?? null, tint: { r: 255, g: 255, b: 255 }, opacity: 100, flipX: false, flipY: false, pivot: options.pivot ?? { x: .5, y: .5 }, size: options.size ?? { x: 1, y: 1 }, sortingLayer: options.layer ?? 1, orderInLayer: options.order ?? 0, material: 'Default', filterMode: options.filterMode ?? 'Linear', nineSlice: { enabled: false, left: 0, top: 0, right: 0, bottom: 0 } }))
  else if (kind === 'ParallaxLayer' || kind === 'CanvasLayer' || kind === 'Empty') { /* Transform-only hierarchy host. */ }
  else components.push(authoringComponent(seed, 'ShapeRenderer2D', { shape: options.shape ?? 'Rectangle', vertices: options.vertices ?? [{ x: -.5, y: -.5 }, { x: .5, y: -.5 }, { x: .5, y: .5 }, { x: -.5, y: .5 }], radiusX: .5, radiusY: .5, color: options.color ?? { r: 105, g: 165, b: 255 }, opacity: 100, strokeColor: { r: 230, g: 240, b: 255 }, strokeOpacity: 100, strokeWidth: .04, sortingLayer: options.layer ?? 1, orderInLayer: options.order ?? 0, material: 'Default', filterMode: options.filterMode ?? 'Linear' }))
  return { uuid: stableUuid(`entity:${seed}`), name: options.name ?? `${kind} ${seed}`, enabled: true, editorVisible: true, editorLocked: false, tags: options.tags ?? [], persistentAcrossScenes: false, prefabAsset: options.prefabAsset ?? null, prefabInstanceUuid: options.prefabInstanceUuid ?? null, prefabSourceUuid: options.prefabSourceUuid ?? null, prefabOverrides: options.prefabOverrides ?? {}, prefabLayers: options.prefabLayers ?? [], sceneLayers: [], authoring: { kind, origin: { x: 0, y: 0 }, visible: true, zOrder: options.order ?? 0, renderLayer: options.layer ?? 1, sortMode: options.sortMode ?? 'LayerThenOrder', canvasLayer: { screenSpace: false, followCamera: true }, parallax: options.parallax ?? { motionScale: { x: 1, y: 1 }, repeat: { x: 0, y: 0 } }, path: { closed: false, smoothing: 0, points: [] } }, entityType: options.entityType ?? 'Box', components }
}
const authoringProject = (slug, name, entities, assets = []) => {
  const project = structuredClone(baseAuthoringProject)
  project.engineVersion = '3.4.0'; project.projectMetadata.name = name; project.projectMetadata.template = slug; project.manifest.name = name
  project.scenes[0].name = 'Authoring Demonstration'; project.scenes[0].entities = entities; project.assets = assets
  return project
}
const pixelAssetUuid = stableUuid('asset:pixel-art')
const pixelSource = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="16" height="16"%3E%3Cpath fill="%236aa8ff" d="M0 0h8v8H0zm8 8h8v8H8z"/%3E%3C/svg%3E'
const pixelHash = createHash('sha256').update(pixelSource).digest('hex')
const pixelAsset = { uuid: pixelAssetUuid, name: 'Pixel Marker.svg', path: 'Assets/Sprites/Pixel Marker.svg', assetType: 'image', mimeType: 'image/svg+xml', byteLength: pixelSource.length, source: pixelSource, sourceModified: 0, importedAt: 0, width: 16, height: 16, duration: 0, fontFamily: '', settings: { filterMode: 'Nearest', compression: 'Lossless', colorSpace: 'sRGB', pixelArt: true, pixelsPerUnit: 16, spriteRegion: null, pivot: { x: .5, y: .5 }, atlas: true, transparentTrim: true, spriteSheet: { columns: 1, rows: 1, margin: 0, spacing: 0 }, borders: { left: 0, top: 0, right: 0, bottom: 0 } }, pipeline: { importerVersion: 'nova-image-3.3', platform: 'web', sourceHash: pixelHash, artifactHash: pixelHash, contentHash: pixelHash, cacheKey: pixelHash, dependencies: [], reverseDependencies: [] } }
const pixelEntities = [authoredEntity('pixel-camera', 'Camera', 0, 0, { pixelPerfect: true, orthographicSize: 6 }), ...Array.from({ length: 24 }, (_, index) => authoredEntity(`pixel-${index}`, 'Sprite', index % 8 - 3.5, Math.floor(index / 8) - 1, { spriteAsset: `asset://${pixelAssetUuid}`, filterMode: 'Nearest', size: { x: 1, y: 1 } }))]
await writeProjectBundle('authoring-pixel-art', authoringProject('authoring-pixel-art', 'Pixel Art Authoring', pixelEntities, [pixelAsset]), ['nearest filtering', 'pixel-perfect camera', 'sprite asset drop', 'selection outlines at multiple zooms'])

const resolutionEntities = [authoredEntity('resolution-camera', 'Camera', 0, 0, { orthographicSize: 10 }), ...Array.from({ length: 15 }, (_, index) => authoredEntity(`resolution-${index}`, index % 3 === 0 ? 'WorldText' : 'Rectangle', (index % 5 - 2) * 3, (Math.floor(index / 5) - 1) * 3, { scale: { x: 2, y: 1 }, color: { r: 92 + index * 6, g: 145, b: 225 } }))]
await writeProjectBundle('authoring-resolution-independent', authoringProject('authoring-resolution-independent', 'Resolution Independent Authoring', resolutionEntities), ['world-unit scaling', 'common-resolution overlays', 'vector shapes', 'camera aspect previews'])

const parallaxRoot = authoredEntity('parallax-root', 'ParallaxLayer', 0, 0, { name: 'Parallax 0.35x', parallax: { motionScale: { x: .35, y: .35 }, repeat: { x: 32, y: 18 } } })
const parallaxEntities = [authoredEntity('parallax-camera', 'Camera', 0, 0, { orthographicSize: 8 }), parallaxRoot, ...Array.from({ length: 30 }, (_, index) => authoredEntity(`parallax-${index}`, 'Rectangle', (index % 10 - 5) * 4, Math.floor(index / 10) * 3 - 4, { parentUuid: parallaxRoot.uuid, color: { r: 65 + index * 3, g: 100 + index * 2, b: 170 + index } }))]
await writeProjectBundle('authoring-parallax', authoringProject('authoring-parallax', 'Parallax Authoring', parallaxEntities), ['parallax parent layer', 'camera-relative motion scale', 'repeat metadata', 'hierarchy reparenting'])

const cameraEntities = [authoredEntity('camera-a', 'Camera', -5, 0, { name: 'Main Camera', viewport: { x: 0, y: 0, width: .7, height: 1 }, priority: 0 }), authoredEntity('camera-b', 'Camera', 6, 2, { name: 'Mini Map Camera', viewport: { x: .72, y: .04, width: .25, height: .3 }, orthographicSize: 18, priority: 1 }), authoredEntity('camera-c', 'Camera', 0, 0, { name: 'Pixel Preview Camera', pixelPerfect: true, viewport: { x: .72, y: .38, width: .25, height: .3 }, priority: 2 }), ...Array.from({ length: 36 }, (_, index) => authoredEntity(`camera-subject-${index}`, 'Rectangle', index % 9 * 2 - 8, Math.floor(index / 9) * 2 - 3))]
await writeProjectBundle('authoring-multiple-cameras', authoringProject('authoring-multiple-cameras', 'Multiple Camera Authoring', cameraEntities), ['camera stacking', 'split viewports', 'pixel-perfect preview', 'camera frame overlays'])

const vehicleAssetUuid = '00000000-0000-4000-8000-000000000101', wheelAssetUuid = '00000000-0000-4000-8000-000000000102', prefabSource = '{}', prefabHash = createHash('sha256').update(prefabSource).digest('hex')
const nestedAssets = [{ uuid: vehicleAssetUuid, name: 'Vehicle.nova-prefab', path: 'Assets/Prefabs/Vehicle.nova-prefab', assetType: 'prefab' }, { uuid: wheelAssetUuid, name: 'Wheel.nova-prefab', path: 'Assets/Prefabs/Wheel.nova-prefab', assetType: 'prefab' }].map(asset => ({ ...asset, mimeType: 'application/x-nova-prefab', byteLength: prefabSource.length, source: prefabSource, sourceModified: 0, importedAt: 0, width: 0, height: 0, duration: 0, fontFamily: '', settings: { filterMode: 'Linear', compression: 'Lossless', pixelsPerUnit: 100, spriteRegion: null, pivot: { x: .5, y: .5 }, atlas: false }, pipeline: { importerVersion: 'nova-prefab-3.3', platform: 'web', sourceHash: prefabHash, artifactHash: prefabHash, contentHash: prefabHash, cacheKey: prefabHash, dependencies: [], reverseDependencies: [] } }))
const nestedRoot = authoredEntity('nested-root', 'Rectangle', 0, 0, { name: 'Vehicle Prefab Root', prefabAsset: `asset://${vehicleAssetUuid}`, prefabInstanceUuid: stableUuid('instance:vehicle'), prefabSourceUuid: stableUuid('source:vehicle'), prefabOverrides: { 'Transform.position.x': 0 }, prefabLayers: [{ asset: `asset://${wheelAssetUuid}`, instanceUuid: stableUuid('instance:wheel'), sourceUuid: stableUuid('source:wheel'), overrides: { 'Sprite.opacity': 85 } }] })
const nestedEntities = [authoredEntity('nested-camera', 'Camera', 0, 0), nestedRoot, ...Array.from({ length: 8 }, (_, index) => authoredEntity(`nested-child-${index}`, index % 2 ? 'Sprite' : 'Rectangle', index - 4, -1, { parentUuid: nestedRoot.uuid, prefabAsset: 'asset://00000000-0000-4000-8000-000000000102', prefabInstanceUuid: stableUuid('instance:wheel'), prefabSourceUuid: stableUuid(`source:wheel:${index}`) }))]
await writeProjectBundle('authoring-nested-prefabs', authoringProject('authoring-nested-prefabs', 'Nested Prefab Authoring', nestedEntities, nestedAssets), ['nested prefab layers', 'per-property overrides', 'status badges', 'world/local reparent modes'])

const stressEntities = [authoredEntity('stress-camera', 'Camera', 50, 25, { orthographicSize: 35 }), ...Array.from({ length: 5_000 }, (_, index) => authoredEntity(`stress-${index}`, index % 11 === 0 ? 'Sprite' : 'Rectangle', index % 100, Math.floor(index / 100), { name: `Stress Object ${String(index + 1).padStart(4, '0')}`, tags: [`row-${Math.floor(index / 100)}`, index % 11 === 0 ? 'sprite' : 'shape'], order: index % 20, color: { r: 70 + index % 140, g: 100 + index % 110, b: 155 + index % 90 } }))]
await writeProjectBundle('authoring-5000-stress', authoringProject('authoring-5000-stress', '5,000 Object Authoring Stress', stressEntities), ['5,000 objects', 'performance mode', 'component and tag search', 'box selection'])

// Minimal, dependency-free Plugin API 2 WASM. It exports the required API
// version and initialization functions and deliberately has no permissions.
const wasm = Uint8Array.from([
  0x00,0x61,0x73,0x6d,0x01,0x00,0x00,0x00,
  0x01,0x05,0x01,0x60,0x00,0x01,0x7f,
  0x03,0x03,0x02,0x00,0x00,
  0x07,0x2e,0x02,
  0x17,0x6e,0x6f,0x76,0x61,0x5f,0x70,0x6c,0x75,0x67,0x69,0x6e,0x5f,0x61,0x70,0x69,0x5f,0x76,0x65,0x72,0x73,0x69,0x6f,0x6e,0x00,0x00,
  0x10,0x6e,0x6f,0x76,0x61,0x5f,0x70,0x6c,0x75,0x67,0x69,0x6e,0x5f,0x69,0x6e,0x69,0x74,0x00,0x01,
  0x0a,0x0b,0x02,0x04,0x00,0x41,0x02,0x0b,0x04,0x00,0x41,0x01,0x0b
])
if (!WebAssembly.validate(wasm)) throw new Error('The generated reference plugin is not valid WebAssembly.')
await writeFile(join(pluginsDirectory, 'hello-plugin.wasm'), wasm)
await writeFile(join(pluginsDirectory, 'plugin.json'), `${JSON.stringify({
  id: 'top.whitelists.novaa.samples.hello', name: 'Hello Plugin API 2', version: '1.0.0', apiVersion: 2,
  engine: '>=3.0.0 <4.0.0', entry: 'hello-plugin.wasm', entryType: 'wasm', permissions: [], enabled: true,
  projectEnabled: true, sha256: createHash('sha256').update(wasm).digest('hex'), signature: '', publicKey: '', contributions: {}
}, null, 2)}\n`, 'utf8')

await writeFile(join(output, 'workspace-recovery-validation.nova-workspaces'), `${JSON.stringify({
  format: 'nova-workspaces', version: 2,
  workspaces: [{ id: 'validation-layout', name: 'Recovery Validation', page: 'scene', hierarchyVisible: true, inspectorVisible: true, bottomPanelVisible: true, bottomPanelOpen: true, bottomPanelTab: 'project', bottomPanelHeight: 300, hierarchyWidth: 260, inspectorWidth: 310, hierarchyDock: 'left', inspectorDock: 'right' }]
}, null, 2)}\n`, 'utf8')

await writeFile(join(output, 'README.md'), `# Nova_A 3.4 reference projects

These are generated, schema-valid source projects. Open any \`.nova\` file through **File → Import Project**, inspect it, press **Play**, run its project tests, and export it from **Build Settings**.

| Project | Demonstrates |
| --- | --- |
| \`empty.nova\` | Camera, input map, scene editing, save/load, and build settings |
| \`platformer.nova\` | Platformer movement, collisions, tilemap, animation, audio, lighting/shadows, UI, scripts, and export |
| \`top-down.nova\` | Top-down input, prefabs, particles, triggers, scene transitions, and Save API |
| \`physics-sandbox.nova\` | Rigid bodies, materials, joints, Rope2D, collision diagnostics, and physics monitoring |
| \`platformer-character/project.nova\` | Character slopes, steps, floor snap, moving platforms, edges and ceilings |
| \`top-down-character/project.nova\` | Top-down character motion, named collision layers, and triggers |
| \`joint-showcase/project.nova\` | Seven joint workflows, limits, motors and break thresholds |
| \`trigger-showcase/project.nova\` | Stable trigger enter/stay/exit ordering and contact data |
| \`ccd-test/project.nova\` | Continuous collision reference against thin geometry |
| \`stacking-test/project.nova\` | Stacking, friction, restitution, sleep and wake stability |
| \`ui-showcase.nova\` | Responsive UI, text input, themes, localization, focus navigation, and audio mixer |
| \`networked-optional.nova\` | Opt-in networking package, replication, prediction, diagnostics, and headless test configuration |
| \`workspace-recovery-validation.nova\` | Workspace import/export, docking, 100-step undo, autosave recovery, safe layout, and read-only recovery qualification |
| \`data-foundation-validation.nova\` | Manifest, nested scenes/prefabs, overrides, imported hashes, dependency graph, and missing-resource repair |
| \`authoring-pixel-art/project.nova\` | Nearest filtering, pixel-perfect camera, sprite drops, and zoom comparisons |
| \`authoring-resolution-independent/project.nova\` | World-unit scaling and common-resolution overlays |
| \`authoring-parallax/project.nova\` | Parallax hierarchy, motion scale, and repeat metadata |
| \`authoring-multiple-cameras/project.nova\` | Camera stacking, viewports, previews, and overlays |
| \`authoring-nested-prefabs/project.nova\` | Nested prefab layers, overrides, and hierarchy statuses |
| \`authoring-5000-stress/project.nova\` | 5,000-object viewport, search, navigation, and selection workload |

\`plugins/hello-plugin\` is a minimal, permission-free Plugin API 2 package. Import its manifest in **Packages → Plugin API** and select the included WASM entry. Plugin failures are isolated and can be bypassed with Safe Mode.

Import \`workspace-recovery-validation.nova-workspaces\` from **View → Manage Workspaces**. The validation project is deliberately small enough to exercise repeated edits, 100 undo/redo operations, autosave snapshots, forced termination, safe-layout startup, and monitor recovery without unrelated content noise.

Generated by \`pnpm references\`. Do not hand-edit generated project files; edit \`src/projects/templates.ts\` and regenerate them.
`, 'utf8')

console.log('Generated eight foundation projects, seven v3.4 physics references, six authoring projects, a workspace fixture, and one Plugin API 2 package.')
