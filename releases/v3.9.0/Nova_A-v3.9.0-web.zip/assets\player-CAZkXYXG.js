import{fA as r,fz as a}from"./crashReporter-DOiOT1Fj.js";import{L as p}from"./vue-runtime-1sAgQeXI.js";import"./nova-runtime-CW1ZxohJ.js";r("Nova Player");p(a).mount("#app");
