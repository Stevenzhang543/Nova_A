import { reactive } from 'vue'
import { buildHistory, buildSettings } from './buildSettings'
import { feedbackDiagnostics } from './editorFeedback'
import { faultDiagnostics } from './faultCenter'
import { packageState } from './packages'
import { PLATFORM_SUPPORT_MATRIX } from './platformSupport'
import { recoveryDiagnostics } from './recovery'
import { stableContractDiagnostics } from './stableContracts'

export interface KnownIssue { severity: 'S2' | 'S3'; area: string; issue: string; workaround: string }
export const KNOWN_ISSUES: readonly KnownIssue[] = Object.freeze([
  Object.freeze({ severity: 'S2', area: 'Linux/macOS qualification', issue: 'Linux and macOS do not yet have the clean-machine evidence required for a stable tier.', workaround: 'Use the platform badge and run the supplied CI/reference matrix on matching hardware.' }),
  Object.freeze({ severity: 'S2', area: 'Package trust', issue: 'Stable accepts only packages verified by the pinned Nova_A trust record in 3.9.0.', workaround: 'Use Preview only for isolated authoring; publish signed packages after validation.' }),
  Object.freeze({ severity: 'S3', area: 'Large worlds', issue: 'World streaming memory values are author estimates rather than operating-system allocation measurements.', workaround: 'Use conservative estimates and compare Profiler captures on target hardware.' }),
  Object.freeze({ severity: 'S3', area: 'Networking', issue: 'The optional networking package remains Experimental.', workaround: 'Do not treat networking as a 4.0 core stability guarantee.' })
])

export const supportState = reactive({ includeProjectIdentifiers: false, includeFilePaths: false, privacyReviewed: false, lastExport: '' })

function download(name: string, contents: string): void {
  const url = URL.createObjectURL(new Blob([contents], { type: 'application/json' })), anchor = document.createElement('a')
  anchor.href = url; anchor.download = name; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 0)
}

export function diagnosticBundle(): Record<string, unknown> {
  const sanitize = (source: string) => supportState.includeFilePaths ? JSON.parse(source) : JSON.parse(source.replace(/[A-Za-z]:\\[^"\n]+|\/(?:Users|home)\/[^"\n]+/g, '[redacted-path]'))
  return {
    format: 'nova-diagnostic-bundle', version: 1, generatedAt: new Date().toISOString(), privacy: { projectIdentifiers: supportState.includeProjectIdentifiers, filePaths: supportState.includeFilePaths, uploaded: false },
    contracts: JSON.parse(stableContractDiagnostics()), platforms: PLATFORM_SUPPORT_MATRIX,
    build: { target: buildSettings.target, profile: buildSettings.profile, recent: buildHistory.slice(0, 10).map(item => ({ ...item, outputPath: supportState.includeFilePaths ? item.outputPath : '[redacted-path]' })) },
    packages: { installed: packageState.installed.map(item => ({ id: item.manifest.id, version: item.manifest.version, securityStatus: item.securityStatus, enabled: item.enabled })), quarantine: packageState.quarantine },
    faults: sanitize(faultDiagnostics()), tasks: sanitize(feedbackDiagnostics()), recovery: sanitize(recoveryDiagnostics()), knownIssues: KNOWN_ISSUES
  }
}

export function exportDiagnosticBundle(): boolean {
  if (!supportState.privacyReviewed) return false
  const source = `${JSON.stringify(diagnosticBundle(), null, 2)}\n`, name = `Nova_A-3.9.0-diagnostics-${new Date().toISOString().slice(0, 10)}.json`
  download(name, source); supportState.lastExport = name; return true
}
