# Web Deployment Reference

Engine **3.9.0**, Project Format 2, schema 29.

Demonstrates: Tier-1 browser matrix, deterministic web package, HTTPS/MIME deployment, size, dependency and patch reports.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking project-format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm nova export --project ./reference-projects/projects/web-deployment/project.nova --target web --profile release --output ./Builds/reference-web-deployment --cache validate --jsonl
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
