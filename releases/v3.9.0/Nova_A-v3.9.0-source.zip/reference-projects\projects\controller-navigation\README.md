# Nova_A Controller Navigation

Engine **3.9.0**, Project Format 2, schema 29.

Demonstrates: focus-order visualization, keyboard and gamepad directional navigation.

1. Open `project.nova` from Project Manager.
2. Confirm Project Health has no blocking project-format error.
3. Use Play, Pause, Step, and Stop; compare the scene/entity minimums with `expected-output.json`.
4. Run the validation export:

```powershell
pnpm nova export --project ./reference-projects/projects/controller-navigation/project.nova --target web --profile release --output ./Builds/reference-controller-navigation --cache validate --jsonl
```

The exact keyboard and UI controls are recorded in `test-controls.json`.
